document.addEventListener('DOMContentLoaded', function(){
  const form = document.getElementById('bookingForm');
  const yearSpan = document.getElementById('year');

  if(yearSpan){
    yearSpan.textContent = new Date().getFullYear();
  }

  if(form){
    form.addEventListener('submit', function(e){
      e.preventDefault();
      e.stopPropagation();

      const name = form.querySelector('[name="name"]').value;
      const email = form.querySelector('[name="email"]').value;
      const date = form.querySelector('[name="date"]').value;

      let oldData = localStorage.getItem('lesothobookings');
      let bookings = [];
      if(oldData){
        bookings = JSON.parse(oldData);
      }

      bookings.push({ name: name, email: email, date: date, id: Date.now() });

      localStorage.setItem('lesothobookings', JSON.stringify(bookings));

      alert('Thank you! Booking saved. Total: ' + bookings.length);
      form.reset();
      return false;
    });
  }
});


const contact = document.getElementById('contact');
if (contact) {
  contact.addEventListener('submit', function(e) {
    e.preventDefault(); // stop page reload

    const name = document.getElementById('cName').value.trim();
    const email = document.getElementById('cEmail').value.trim();
    const message = document.getElementById('cMessage').value.trim();

    if (name === '' || email === '' || message === '') {
      alert('Please fill all fields lala!');
      return;
    }

    
    const contactData = { name, email, message, date: new Date().toLocaleString() };
    localStorage.setItem('lesothoContact', JSON.stringify(contactData));

    // show success
    document.getElementById('contactSuccess').style.display = 'block';
    contact.reset();

    setTimeout(() => {
      document.getElementById('contactSuccess').style.display = 'none';
    }, 4000);
  });
}